/********************************************************************
*  Program arguments processing utility 
*  -----------------------------------
*  Written by Tianzhu Qiao<ben.qiao@gmail.com>
*  ----------------
*
*  This program is free software; you can redistribute it and/or modify
*  it as long as you keep this header.
*   --------
*	History:
*   --------
*    1.1: 2008.01
*        [1] : fix some confusing variable-name
*        [2] : update Get* functions 
*    1.0 : first version 2006.09
*        [1] : basic function
*        [2] : read arguments from the file
*
*   ------
*   Usage:
*   ------
*     [ex]: <exe> -options value0 value1 -argf args.txt ...
*     <exe>    : your program
*     -options : one argument 
*      value0  : the first value of argument '-options'
*      value1  : the second value of argument '-options'
*     -argf    : load the arguments from the file
*      args.txt: the file contians the arguments 
*      .......
*      
*      ----------------------
*      In your main function:
*      ----------------------
*       static char Utxt[] = {...};       //-->optional
*       static char *Arguments[] = {...}; //-->optional
*       alias_ps alias_g[] = {...}        //-->optional
*
*		int main(int argc, char *argv[])
*       {
*           SetUsageHint(Utxt);           //-->optional, set the help tip for your program
*	        SetAlias(3,alias_g);          //-->optional, set the arguments' value alias  
*	        SetArgumentTable(5,Arguments);//-->optional, set the arguments list your program support
*           SetSwitchChar("-");           //-->optional, set the switch character(s), default value is "-/\\"
*
*          	InitProg(argc,argv);          //-->mandatory
*           
*            //GetIntArg(...)
*            //GetStrArg(...)
*            //GetDoubleArg(...)
*            //GetFlagArg(...)
*            .....
*        }
*                       
*
* Arguments File Example:
* ----------------------
*   -itype Bin
*   -ibyte 2
*   -BigEndian
*   #strArg has 1 value: stringargument
*   -strArg stringargument
*   #strArg1 has 1 value: string argument
*   -strArg1 "string argument"
*   #strArg2 has 2 values , 1-->string ,2--> argument
*   -strArg2 string argument
*   #strArg3 has 1value: string * # argument
*   -srtArg3 "string \* \# argument"
*                                                
*********************************************************************/

#ifndef __progarg_h
#define __progarg_h

/************************************************************
* alias table struct
************************************************************/
namespace ps{
	typedef struct alias_ps
	{
		char    *name;
		double  value;
	}alias_ps,*Alias_ps;
}
using  ps::alias_ps;

/************************************************************
* show the help text
* [Description]:
*    If this function is called, the main program will exit 
*    after print out the help text
*
* [Arguments]:
*    
* [Return value]:
*    
************************************************************/
void PrintUsageHint  ();

/************************************************************
* set the help text
* [Description]:
*
* [Arguments]:
*    
* [Return value]:
*    
************************************************************/
bool SetUsageHint    (char *usagestr);

/************************************************************
* show the version text
* [Description]:
*
* [Arguments]:
*    
* [Return value]:
*    
************************************************************/
void PrintVersionHint();

/************************************************************
* set the version info
* [Description]:
*
* [Arguments]:
*    
* [Return value]:
*    
************************************************************/
bool SetVersionHint  (char *ver);

/************************************************************
* set the switch characters
* [Description]:
*    the default value  : "-/\\"
*    the maximun length : 15
*    all invisible characters will be ignored
*
* [Arguments]:
*    char *swc : switch characters
*
* [Return value]:
*    true : success
*    false: otherwise
************************************************************/
bool SetSwitchChar   (char *swc);

/************************************************************
* initializing the utility
* [Description]:
*    This function should be called before calling any
*    other functions in this utility
*
* [Arguments]:
*    the two arguments are simply coming from 
*    the counterparts of the main() function:
*    (ex: int main(int argc, char *argv[]))
*
* [Return value]:
*    true : success
*    false: otherwise
************************************************************/
bool InitProg(int argc,   char *argv[]);

/************************************************************
* free the memory used by the utility
* [Description]:
*    If you are sure you have finished using the utility, 
*    call this function to free the memory.
*    At the end of the program, this function will be called.
*
* [Arguments]:
*
* [Return value]:
*
************************************************************/
void ExitProg();

/************************************************************
* set the valid arguments table
* [Description]:
*    If the table is not set, all arguments will be viewed as valid;
*    If the table is set, any unvalid input argument will 
*    stop the program
*
* [Arguments]:
*	 int argc        : valid arguments table length
*    char **argtable : valid arguments table
*
* [Return value]:
*    true : success
*    false: otherwise
************************************************************/
bool SetArgumentTable(int argc,char **argtable);

/************************************************************
* check if all the arguments are valid argument
* [Descriptin]:
*    If the valid arguments table is not set, all argument will 
*    be viewed as valid.
*
* [Arguments]:
*
* [Return value]:
*    true : all arguments are valid
*    false: some invalid arguments are typed in
************************************************************/
bool CheckArgument();

/************************************************************
* get the argument value
* [Description]
*    Get the argument value by the 'argument name' and 
*    'argument value position'.
*
* [Arguments]
*    char *name               : the argument name
*    [int,double,char*] &value: the returned argument value
*    const unsigned int &pos  : the position of the argument value
*                               (ex: -option value0 value1 value1)
* [Return value]:
*    true  : success
*    false : otherwise, the 'value' argument will not be changed
************************************************************/
bool GetIntArg   (char *name, int    &value,    const unsigned int &pos = 0);
bool GetStrArg   (char *name, char   **value,   const unsigned int &pos = 0);
bool GetDoubleArg(char *name, double &value,    const unsigned int &pos = 0);
bool GetFlagArg  (char *name);

/************************************************************
* Set the table of alias name 
* [Description]
*    You could set the alias table, which means that you could 
*    give your argument value a more meaningful name.
*    [ex]:
*       you coule input:
*         <exe> -inputfiletype ASCII
*       rather than :
*         <exe> -inputfiletype 1
*    see 'struct alias_ps' for how to generate the alias table
*
* [Arguments]
*    int      alias          : alias table length
*    alias_ps *aliasv        : alias table
*
* [Return value]:
*    true  : success
*    false : otherwise
************************************************************/
bool SetAlias   (int aliasc, alias_ps *aliasv);

/************************************************************
* Get the argument value from the alias table
* [Description] 
*    The similar function as GetIntArg() & GetDoubleArg()
*    But it will look up the input argument value in the alias table
*    to find the actual integer value.
************************************************************/
bool GetIntArg2   (char *name, int    &value,    const unsigned int &pos = 0);
bool GetDoubleArg2(char *name, double &value,    const unsigned int &pos = 0);

#endif