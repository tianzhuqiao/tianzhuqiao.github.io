/********************************************************************
*  Program arguments processing utility 
*  -----------------------------------
*  Written by Tianzhu Qiao<ben.qiao@gmail.com>
*  ----------------
*
*  This program is free software; you can redistribute it and/or modify
*  it as long as you keep this header.
*   --------
*	History:
*   --------
*    1.2: 2009.07
*        [1] : stop the program when some erros occur during processing
*        [2] : output more information for debugging
*    1.1: 2008.01
*        [1] : fix some confusing variable-name
*        [2] : update Get* functions 
*    1.0 : first version 2006.09
*        [1] : basic function
*        [2] : read arguments from the file
*
*********************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "progarg.h"

namespace ps
{
#define MAX_LINE_LEN 1024
#define MAX_SWITCH_LEN 16

	char   *usage_str          = NULL;
	const char*usage_str_foot  = 
		"\t--=---------------------------------------------=--\n"
		"\t-argf               : Load arguments from file\n"
		"\t-v[erbose]          : Explain what is being done\n"
		"\t-h[elp]|--help|-?   : Display this help and exit\n"
		"\t-version            : Output version information and exit\n";
	
	char switch_char[MAX_SWITCH_LEN+1] = "-/\\";  

    //argument from the command line
	int  arg_num                   = 0;
	char **arg_array               = NULL;

	//arguments from the file,allocate the menory for these arguments
	int  argf_mem_num	           = 0;
	int  argf_num                  = 0;
	char **argf_array              = NULL;

	char *version_str              = NULL;

	int   alias_num                = 0;
	alias_ps *alias_array          = NULL;

	char   **arg_val_array         = NULL; 
	int    arg_val_num             = 0;

	const char   *arg_rsv_array[]  = {
		"argf",
		"h","help","-help","?",
		"v","verbose",
		"version"
	}; 
	const int   arg_rsv_num         = 8;

	//auto clear the memroy
	//ugly code :)
	struct ps_clear
	{
		~ps_clear()
		{
			ExitProg();
		}
	}auto_clear;
};

/************************************************************
* load the argument table from the file
* [Description]:
*
* [Arguments]:
*    char *fname : the file name 
*
* [Return value]:
*    true : success
*    false: otherwise
*
************************************************************/
bool LoadProgFile(char *fname);

/************************************************************
* search the argument from the table
* [Description]:
*
* [Arguments]:
*    char *name   : argument name
*    int argn     : arguments table length
*    char *argv[] : arguments table
*    int &index   : returned index of the argument "name" in the arguments table  
*
* [Return value]:
*    true : success
*    false: otherwise
*
************************************************************/
bool ScanArgvV   (char *name,int  argn,  char *argv[],int &index);

/************************************************************
* search the argument
* [Description]:
*
* [Arguments]:
*    char *name   : argument name
*    int &index   : returned index of the argument "name" in the arguments table  
*					if(index>=arg_num), the argument "name" is in the argf_array table
*
* [Return value]:
*    true : success
*    false: otherwise
*
************************************************************/
bool ScanArgv    (char *name, int &index);

/************************************************************
* decide if ch belongs to the switch characters
* [Description]:
*
* [Arguments]:
*    char &ch  : the character to be decided
*
* [Return value]:
*    true : yes
*    false: no
*
************************************************************/
bool IsSwitchChar(char &ch);

/************************************************************
* check if all the input arguments are valid(belong to the "arg_val_array" or "arg_rsv_array"?)
* [Description]:
*
* [Arguments]:
*    int argn     : arguments table length
*    char *argv[] : arguments table
*
* [Return value]:
*    true : yes
*    false: no
*
************************************************************/
bool IsValidArug (int  argn,  char *argv[]);

void PrintUsageHint()
{
	using namespace ps;
	if(usage_str)
	{
		fprintf(stdout, "%s\n",  usage_str );
	}
	if(usage_str_foot)
	{
		fprintf(stdout, "%s\n",  usage_str_foot );
	}
	exit(1);
}

void PrintVersionHint()
{
	using namespace ps;
	if(version_str)
	{
        fprintf(stdout, "%s\n",  version_str);
	}
	else
	{
		fprintf(stdout, "\t--==--To be defined--=--\n");
	}
	exit(1);
}

bool SetUsageHint(char *usagestr)
{
	using namespace ps;
	usage_str = usagestr;
	return true;
}

bool SetVersionHint(char *ver)
{
	using namespace ps;
	version_str = ver;
	return true;
}

bool SetSwitchChar (char *swc)
{
	using namespace ps;
	int len = (int)strlen(swc);
	if(len == 0)
	{
		fprintf(stderr, "No switch character(s) definied;");
		fprintf(stderr,	"Use the reserved switch-character(s): %s\n",switch_char);
		return false;
	}
	if(len>MAX_SWITCH_LEN)
	{
		fprintf(stderr, "Too many switch characters;");
		fprintf(stderr,	"Use the reserved switch-character(s): %s\n",switch_char);
		return false;
	}
	char *ch = swc;
	int i=0;
	for(i=0; i<MAX_SWITCH_LEN && *ch!='\0'; ch++)
	{
		if(*ch>='!'&&*ch<='~')//visible character
		{
			switch_char[i] = *ch;
			i++;
		}
	}
	switch_char[i] = '\0';
	return true;
}

bool SetArgumentTable(int argc,char **argtable)
{
	using namespace ps;
	arg_val_array   = argtable;
	arg_val_num     = argc; 
	return true;
}

bool IsValidArug(int argc, char *argv[])
{
	using namespace ps;
	//not set the valid argument table, return true
	if(arg_val_num == 0)
		return true;
	bool result = true;
	for(int i=0; i<argc; i++)
	{
		if(IsSwitchChar(argv[i][0]))
		{
			int j;
			for(j=0; j<arg_rsv_num; j++)
			{
				if(strcmp(argv[i]+1,arg_rsv_array[j]) ==0 )
					break;
			}
			//couldn't find it in the reserved argument-list
			if(j==arg_rsv_num)
			{
				for(j=0; j<arg_val_num; j++)
				{
					if(strcmp(argv[i]+1,arg_val_array[j]) ==0 )
						break;
				}
				if(j == arg_val_num)
				{
					fprintf(stderr, "Invilad option: %s\n",argv[i]);
					
					result = false;
				}
			}
		}
	}	
	return result;
}

bool CheckArgument()
{
	using namespace ps;
	//check if all the arguments are valid
	return (IsValidArug(arg_num, arg_array) && IsValidArug(argf_num,argf_array));
}

bool InitProg(int argc, char *argv[])
{
	using namespace ps;
	//argument from the command line
	arg_num = argc;
	arg_array = argv;
	if(arg_array==NULL)
		return false;
	//argument from the argument definition file
	char *tmp = NULL;
	//Need to load the arguments form the file?
	if(GetStrArg("argf",&tmp))
	{
		LoadProgFile(tmp);
	}
	if(!CheckArgument())
	{
		char *exe = NULL;
		exe = strrchr(arg_array[0],'\\');
		if(exe == NULL)
			exe = arg_array[0];
		else
			exe++;
        fprintf(stderr, "Try %s -h[elp] for more information\n",exe);
		exit(0);
	}

	//Need to show the help information?
	if(GetFlagArg("help")||GetFlagArg("h")||GetFlagArg("-help")||GetFlagArg("?"))
	{
		PrintUsageHint();
	}
	//Need to show the version information?
	if(GetFlagArg("version"))
	{
		PrintVersionHint();
	}
	
	return true;
}

bool LoadProgFile(char *fname)
{
	using namespace ps;
	FILE *ifp =NULL;
	ifp = fopen(fname,"r");
	if(ifp == NULL)
	{
		fprintf(stderr, "Couldn't open option file %s\n", fname);
		PrintUsageHint();
		return false;
	}

	char str2[MAX_LINE_LEN];
	//Parse the file
	bool sentence_flag = false;
	bool newword_flag  = false;
	bool comment_flag  = false;
	int  word_len      = 0;
	char ch            = '#';
	char ch_pre        = '#';

	while(ifp&&feof( ifp ) == 0)
	{
		ch_pre = ch;
		ch     = fgetc( ifp );
		if( ferror( ifp))
		{
			break;
		}
        //comment words, 
		if(comment_flag)
		{
			if(ch == '\n')//reach the comment end
			{
				comment_flag = false;
			}
			else//ignore the comment
			{
				continue;
			}
		}
		//set comment flag
		if(ch_pre!='\\'&&ch == '#')
		{
			comment_flag = true;
			//finish reading a word
			newword_flag = true;
		}
		else if (!sentence_flag)//ignore all the invisible characters
		{
            if(ch>='!'&&ch<='~')//visible character
			{
				newword_flag = false;
			}
			else //invisible charecter, finishning reading a word
			{
				newword_flag = true;
			}
		}
		if(ch_pre!='\\'&&ch == '\"')//the argument value is a sentence with space character
		{
			sentence_flag = !sentence_flag; //sentence flag, in setence mode, we will accept all characters until we reach another '\"'
			newword_flag = true;//finishning reading a word
		}

		if(newword_flag)
		{
			if(word_len>0)
			{
				str2[word_len] = '\0';

				//no more space for a new argument, reallocate a bigger one
				if(argf_num>=argf_mem_num)
				{
					argf_mem_num = argf_mem_num+10;
					char **argvf2_ps = new char *[argf_mem_num];
					int i = 0;
					for(i=0; i<argf_num; i++ )
					{
						argvf2_ps[i] = argf_array[i];
					}
					for(i=argf_num; i<argf_mem_num ;i++)
					{
						argvf2_ps[i] = NULL;
					}
					if(argf_array)
					{
						delete []argf_array;
						argf_array = NULL;
					}
					argf_array = argvf2_ps;
				}
				//insert a new argument
				char *str3 = new char[strlen(str2)+1];
				strcpy(str3,str2);
				argf_array[argf_num] = str3;
				argf_num++;

				word_len=0;
			}
			newword_flag = false;
		}
		else
		{
			//if the word length >MAX_LINE_LEN, ignore it
			if(word_len<MAX_LINE_LEN-1)
			{
				if(ch_pre=='\\'&&(ch=='#'||ch=='\"')&&word_len>0)
				{
					word_len--;
				}
				str2[word_len] = ch;			
				word_len++;
			}
		}
	}
	fclose(ifp);
	return true;
}

//clear the memory
void ExitProg()
{
	using namespace ps;
	if(argf_array)
	{
		for(int i=0;i<argf_num; i++)
		{
			delete []argf_array[i];
			argf_array[i] = NULL;
		}
		delete []argf_array;
		argf_array = NULL;
		argf_num = 0;
	}
}

//scan the argument table 
bool  ScanArgvV(char *name,int  argn,  char *argv[], int &index)
{
	bool result = false;
	int j = -1;
	for(int i=0;i <argn; i++)
	{
		if(strcmp(argv[i]+1,name)==0&&IsSwitchChar(argv[i][0]))
		{
			j=i;
			break;
		}
	}
	if((j!=-1)&&(index = j))
		result = true;
	return result;
}

bool ScanArgv(char * name,int &index)
{
	using namespace ps;
	
	int idx = -1;
	bool result = false;
	//first search the argument in the command line arguments
	if(ScanArgvV(name,arg_num, arg_array,idx))
	{	
		index  = idx;
		result = true;

	}//if not find the argument in the command line arguments, search it in the arguments file
	else if(ScanArgvV(name,argf_num, argf_array,idx))
	{
		index  = idx + arg_num;
		result = true;
	}
	return result;
}

bool GetStrArg(char *name, char **value, const unsigned int &pos)
{
	using namespace ps;
	int idx = -1;
	char *tmp = NULL;
	bool result = false;
	if(ScanArgvV(name,arg_num, arg_array,idx))
	{
		int idx_tmp = idx+pos; 
		if(idx_tmp<arg_num-1)
		{
			tmp = arg_array[idx_tmp+1];
			result = true;
		}
	}
	else if(ScanArgvV(name,argf_num, argf_array,idx))
	{
		int idx_tmp = idx+pos; 
		if(idx_tmp<argf_num-1)
		{
			tmp = argf_array[idx_tmp+1];
			result = true;
		}
	}
	//Is it a valid argument value?
	if(result&&tmp&&IsSwitchChar(tmp[0]))
		result = false;
	else
		*value = tmp;

	return result;
}

bool GetIntArg(char *name, int& value, const unsigned int &pos)
{
	using namespace ps;

	char *tmp   = NULL;
	bool result = false;
	if(GetStrArg(name,&tmp,pos))
	{
		int value_tmp = 0;
		if(sscanf(tmp,"%i",&value_tmp)==1)
		{
			value = value_tmp;
			result = true;
		}
        else
        {
            fprintf(stderr,"Unknown argument:%s  %s", name,tmp);
            PrintUsageHint();
            exit(0);
        }
	}
	return result;
}

bool GetDoubleArg(char *name, double & value, const unsigned int &pos)
{
	using namespace ps;
	char *tmp = NULL;
	bool result = false;
	if(GetStrArg(name,&tmp,pos))
	{
		double value_tmp = 0.0;
		if(sscanf(tmp,"%lf",&value_tmp)==1)
		{
			value  = value_tmp;
			result = true;
		}
        else
        {
            fprintf(stderr,"Unknown argument:%s  %s", name,tmp);
            PrintUsageHint();
            exit(0);
        }
	}
	return result;
}

bool GetFlagArg(char *name)
{
	using namespace ps;
	int idx = -1;
	return ScanArgv(name,idx);
}

bool SetAlias(int aliasc, alias_ps *aliasv)
{
	using namespace ps;
	alias_num = aliasc;
	alias_array = aliasv;

	return true;
}
bool GetIntArg2(char *name, int& value,const unsigned int &pos)
{
	using namespace ps;
	double temp = 0.0;
	if(GetDoubleArg2(name,temp,pos))
	{
        value = (int)temp;
		return true;
	}
	return false;
}

bool GetDoubleArg2(char *name, double &value,    const unsigned int &pos)
{
	using namespace ps;

	char *tmp = NULL;
	if(GetStrArg(name,&tmp, pos))
	{
		for(int i=0; i<alias_num; i++ )
		{
			if(strcmp(tmp,alias_array[i].name)==0)
			{
				value = alias_array[i].value;
				return true;
			}
		}
        fprintf(stderr,"Unknown argument:%s  %s", name,tmp);
        PrintUsageHint();
        exit(0);
	}

	return false;
}

bool IsSwitchChar(char &ch)
{
	using namespace ps;
	if(strchr(switch_char,ch))
	{
		return true;
	}
	return false;
}
