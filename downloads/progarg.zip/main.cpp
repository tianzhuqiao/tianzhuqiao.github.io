/********************************************************************
 *
 * $Id: main.cpp,v  $
 *
 * $(c)$
 * 
 * $Log: main.cpp,v $
 *
 *********************************************************************/

#include <stdlib.h>
#include <stdio.h>
//#include <iostream>
//using namespace std;
//#include "vld.h"
#include "progarg.h"
static char Utxt[] = "\n" 
"\t (-in)              : input file name\n"
"\t (-factor)          : the scale factor to the source data \n"
"\t (-itype)           : Input file type\n"
"\t                       : Bin         --> Binary<default>\n"
"\t                       : Bin_o       --> offset binary\n"
"\t                       : ASCII_int   --> ASCII int\n"
"\t                       : ASCII_float --> ASCII float\n"
"\t (-ibyte) (1|2)     : input data bytes for Binary format\n"
"\t (-BigEndian)       : big endian input\n"
"\t (-strarg)          : argument only for test\n"
"\t (-strarg1)         : argument only for test\n"
"\t (-strarg2)         : argument only for test\n"
"\t (-strarg3)         : argument only for test\n"
;

static char *Arguments[]=
{
	"in",
	"factor",
	"itype",
	"ibyte",
	"BigEndian",
	"strArg",
    "strArg1",
	"strArg2",
	"strArg3"
};
enum {FILE_BINARY,FILE_OFFSET_BINARY,FILE_ASCII};


alias_ps alias_g[] = {
	{"Bin",FILE_BINARY},
	{"Bin_o", FILE_OFFSET_BINARY},
	{"ASCII",FILE_ASCII}
};
int main(int argc, char *argv[])
{
	
	SetUsageHint(Utxt);
	SetAlias(3,alias_g);
	SetArgumentTable(9,Arguments);
	SetSwitchChar("-");
	InitProg(argc,argv);

	char *inFileName = NULL;
	if(!GetStrArg("in",&inFileName))
	{
		fprintf(stderr, ("Option <-in> couldn't be empty\n"));
		exit(0);
	}
	
	int itype = FILE_BINARY;
	GetIntArg2("itype", itype);

	double factor = 0.0;
	GetDoubleArg("factor",factor);
	

	bool littleEndian  = true;
	if(GetFlagArg("BigEndian"))
	{
		littleEndian = 0;
	}
	
	int ibyte = 2;
	GetIntArg("ibyte",ibyte);

	if(ibyte!=1&&ibyte!=2)
	{
		ibyte = 2;
	}

	if(!CheckArgument())
		exit(0);
	fprintf(stdout,"in\t: %s \n",inFileName);
	fprintf(stdout, "ibyte\t: %d \n" ,ibyte );
	fprintf(stdout, "itype\t: %d \n" ,itype );
	fprintf(stdout, "factor\t: %f \n", factor );
	fprintf(stdout, "littleEndian\t: %d\n", littleEndian);

	return 0;
}


